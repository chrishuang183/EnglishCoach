# English Coach (Android MVP)

A small native Android starter app built with Kotlin and Jetpack Compose.

## Included in this first version
- Daily English practice phrases focused on workplace meetings and hardware engineering
- Text-to-speech playback (US English)
- Speech recognition through Android's speech recognition service
- A simple in-session practice counter

## Requirements
- Android Studio (recent stable version)
- JDK 17
- Android SDK Platform 35
- A Pixel or other Android device for testing

## Open and run
1. Unzip this project.
2. Open the `EnglishCoachAndroid` folder in Android Studio.
3. Allow Gradle sync and install any requested SDK components.
4. Connect your Android phone with USB debugging enabled, or use an emulator.
5. Press Run.

## Notes
- This is source code, not a prebuilt APK.
- Speech recognition availability and offline support depend on the speech service installed on the device.
- The first version does not send recordings to a custom server or store a long-term learning history.
- The speech recognizer may display a system interface and may use the device's configured recognition provider.

## Next improvements
- Persistent daily progress using DataStore
- Sentence-by-sentence shadowing mode
- Compare recognized text with the target sentence
- Add custom sentence lists and listening exercises
