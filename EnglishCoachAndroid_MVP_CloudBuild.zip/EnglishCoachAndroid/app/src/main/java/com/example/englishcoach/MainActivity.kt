package com.example.englishcoach

import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

data class PracticePhrase(
    val category: String,
    val english: String,
    val chinese: String,
    val tip: String
)

private val phrases = listOf(
    PracticePhrase("MEETING", "Let me walk you through the latest update.",
        "我來帶大家快速了解最新進度。", "Use this to introduce your project update."),
    PracticePhrase("HARDWARE", "The initial validation is complete.",
        "初步驗證已經完成。", "A concise status update for a hardware project."),
    PracticePhrase("DEBUG", "We are still investigating the root cause.",
        "我們仍在調查根本原因。", "Useful when the issue is not fully understood."),
    PracticePhrase("ALIGNMENT", "I'd like to align with the firmware team on this.",
        "我想在這件事上與韌體團隊達成共識。", "Use 'align with' when coordinating across teams."),
    PracticePhrase("MEETING", "Could you clarify what you mean by that?",
        "你可以再說明一下你的意思嗎？", "A polite way to ask for clarification."),
    PracticePhrase("STATUS", "The document is ready, but we need your feedback.",
        "文件已經準備好了，但我們需要你的回饋。", "Good for reporting a dependency.")
)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.US
            }
        }
        setContent {
            EnglishCoachScreen(
                speak = { text -> tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "phrase") }
            )
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EnglishCoachScreen(speak: (String) -> Unit) {
    val context = LocalContext.current
    var selectedTab by remember { mutableStateOf(0) }
    var selectedPhrase by remember { mutableIntStateOf(0) }
    var recognizedText by remember { mutableStateOf("") }
    var completed by remember { mutableIntStateOf(0) }

    val speechLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val matches = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
        recognizedText = matches?.firstOrNull().orEmpty()
        if (recognizedText.isNotBlank()) completed++
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Color(0xFF2457C5),
            secondary = Color(0xFF00A6A6),
            background = Color(0xFFF5F7FB),
            surface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Color(0xFFF5F7FB),
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("English Coach", fontWeight = FontWeight.Bold)
                            Text("Speak with confidence", fontSize = 12.sp, color = Color.Gray)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFFF5F7FB))
                )
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        icon = { Text("📚") },
                        label = { Text("Practice") }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        icon = { Text("📈") },
                        label = { Text("Progress") }
                    )
                }
            }
        ) { padding ->
            if (selectedTab == 0) {
                LazyColumn(
                    modifier = Modifier.padding(padding).fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF17346B)),
                            shape = RoundedCornerShape(22.dp)
                        ) {
                            Column(Modifier.padding(20.dp)) {
                                Text("TODAY'S GOAL", color = Color(0xFFBFD1F5), fontSize = 12.sp)
                                Spacer(Modifier.height(8.dp))
                                Text("5 useful sentences", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                                Text("Practice English for your next meeting.", color = Color(0xFFE2E9F8))
                                Spacer(Modifier.height(12.dp))
                                LinearProgressIndicator(
                                    progress = { (completed.coerceAtMost(5) / 5f) },
                                    modifier = Modifier.fillMaxWidth(),
                                    color = Color(0xFF62D6C8),
                                    trackColor = Color(0xFF45608F)
                                )
                                Text("$completed practice attempts", color = Color.White, fontSize = 12.sp)
                            }
                        }
                    }
                    item {
                        Text("Practice sentences", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("Listen, repeat, then check your speech.", color = Color.Gray, fontSize = 13.sp)
                    }
                    itemsIndexed(phrases) { index, phrase ->
                        Card(
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White)
                        ) {
                            Column(Modifier.padding(16.dp)) {
                                Text(phrase.category, color = Color(0xFF2457C5), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(8.dp))
                                Text(phrase.english, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                                Spacer(Modifier.height(5.dp))
                                Text(phrase.chinese, color = Color.Gray, fontSize = 14.sp)
                                Spacer(Modifier.height(8.dp))
                                Text(phrase.tip, color = Color(0xFF64748B), fontSize = 12.sp)
                                Spacer(Modifier.height(12.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(onClick = { speak(phrase.english) }) {
                                        Icon(Icons.Default.PlayArrow, contentDescription = "Play")
                                        Spacer(Modifier.width(4.dp))
                                        Text("Listen")
                                    }
                                    Button(onClick = {
                                        selectedPhrase = index
                                        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
                                            putExtra(RecognizerIntent.EXTRA_PROMPT, "Say: ${phrase.english}")
                                        }
                                        try {
                                            speechLauncher.launch(intent)
                                        } catch (_: Exception) {
                                            recognizedText = "Speech recognition is not available on this device."
                                        }
                                    }) {
                                        Icon(Icons.Default.Mic, contentDescription = "Speak")
                                        Spacer(Modifier.width(4.dp))
                                        Text("Speak")
                                    }
                                }
                            }
                        }
                    }
                    if (recognizedText.isNotBlank()) {
                        item {
                            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F3FF))) {
                                Column(Modifier.padding(16.dp)) {
                                    Text("YOUR SPEECH", color = Color(0xFF2457C5), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Spacer(Modifier.height(6.dp))
                                    Text(recognizedText, fontSize = 16.sp)
                                    Spacer(Modifier.height(6.dp))
                                    Text("Tip: Compare this transcript with the target sentence and try again.",
                                        color = Color.Gray, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            } else {
                Column(
                    Modifier.padding(padding).fillMaxSize().padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text("Your progress", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Card(shape = RoundedCornerShape(20.dp)) {
                        Column(Modifier.padding(20.dp)) {
                            Text("Practice attempts", color = Color.Gray)
                            Text("$completed", fontSize = 40.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2457C5))
                            Text("This session", color = Color.Gray, fontSize = 12.sp)
                        }
                    }
                    Text("Keep it simple: listen, speak, and repeat.", color = Color.DarkGray)
                    Text("Your progress currently resets when the app is closed. Persistent history will be added in a later version.",
                        color = Color.Gray, fontSize = 13.sp)
                }
            }
        }
    }
}
